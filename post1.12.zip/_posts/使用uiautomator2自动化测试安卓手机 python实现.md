﻿## 1. 安装adb 
非本文重点 具体可百度谷歌

## 2.首次连接手机并且打开开发者调试模式

使用数据线连接，并打开开发者调试，每个手机型号不同打开方式略有不同，笔者手机是通过点击十次手机ui版本号打开的。

## 3.安装python的uiautomator2模块。

```python
pip install --pre uiautomator2  init
pip install pillow
```

## 4.在手机上初始化

python -m uiautomator2 init

## 5.安装使用可视化工具
pip install --pre --upgrade weditor

安装后使用
python -m weditor 
打开浏览器页面

## 6.python 控制

import uiautomator2
d = uiautomator2.connect("ip for phone")

对d执行操作即可
