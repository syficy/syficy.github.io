﻿# 为啥学vue
[前端top100](https://www.awesomes.cn/rank)排名为1
vue[官网](https://cn.vuejs.org/index.html)


来看官网介绍
>Vue (读音 /vjuː/，类似于 view) 是一套用于构建用户界面的渐进式框架。与其它大型框架不同的是，Vue 被设计为可以自底向上逐层应用。Vue 的核心库只关注视图层，不仅易于上手，还便于与第三方库或既有项目整合。另一方面，当与现代化的工具链以及各种支持类库结合使用时，Vue 也完全能够为复杂的单页应用提供驱动。

渐进式：可以作为应用的一部分嵌入，也就是部分使用，便于重构。

# 安装vue
官方文档
https://cn.vuejs.org/v2/guide/installation.html


## cdn引入
可以选择开发环境版本或者生产环境版本。
开发环境版本，有帮助的命令行警告，生产环境版本压缩了代码，速度快，但是理解难，适合部署。

## 下载 
https://cn.vuejs.org/v2/guide/installation.html
官网下载官方版本


## npm安装

# 配置vue
这边选择第二种方式，使用webstorm打开创建vue，然后在项目目录下创建js文件夹，放入上一步中下载下来的vue.js。

创建html文件

```html

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>


<div id="app">{{message}}</div>

<script src="../js/vue.js"></script>
<script>
    // let变量/const常量 一般不用 var
    const app = new Vue({
        el:'#app',
        data:{
                message:'hello world'
        }
        })
</script>


</body>
</html>
```

# 运行
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191103201106527.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

# 响应式
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191103202815594.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
