﻿# 启用编辑时tab键

![在这里插入图片描述](https://img-blog.csdnimg.cn/20200119142950339.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
如图，首选项->设置中搜索“edtior.tab”，打开 “Tab Completion”

# 打开首选项的 user snippets
然后选择目标文件的后缀名
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200119143010844.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
然后会打开一个配置文件，
使用snippets语法编辑，
其中“prefix”字段是快捷用语，
“body”字段是内容，
如下：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200119143107971.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

```javascript
"hexo template":{
	"prefix": "hexomd",
	"body": [
		"---",
		"title: 标题",
		"date: 2019-09-01 12:08:25",
		"tags: 标签",
		"categories: 分类",
		"---",
		"# 标题",
		"------",
	],
	"description": "hexo template"
}
  ```

最终输入”hexomd“就会打开模块，提高效率
