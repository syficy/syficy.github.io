﻿# 解决ssh连接报错WARNING REMOTE HOST IDENTIFICATION HAS CHANGED!

在远程服务器上重置了系统，生成了新的ssh，使用本地powershell连接时报错

> @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@    WARNING REMOTE HOST IDENTIFICATION HAS CHANGED!     @
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
IT IS POSSIBLE THAT SOMEONE IS DOING SOMETHING NASTY!
Someone could be eavesdropping on you right now (man-in-the-middle attack)!
It is also possible that a host key has just been changed.
The fingerprint for the ECDSA key sent by the remote host is xxxx

但使用mobaxterm连接时正常

解决方法：  删除user目录下.ssh中的 【known_hosts】 文件

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTQvM1g3TjRrY09wS1FvMXJpLnBuZw?x-oss-process=image/format,png) 

重新连接即可
