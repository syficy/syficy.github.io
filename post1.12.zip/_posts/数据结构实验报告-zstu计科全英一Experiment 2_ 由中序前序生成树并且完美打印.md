﻿# 题目
### Experiment 2: Tree
Purpose:
1.	Master the concepts and properties of different Trees;
2.	Master the representation of different Trees;
3.	Understand the way of using Tree structures to solve problems.

Problems and requirements:
【Problem 1】: Draw binary tree based on the traversal sequences.
 Requirements:
Input: The inorder and postorder traversal sequence;
Output: the visual representation of the tree
   Sample input: 4 2 5 1 6 3 7 //inorder traversal result
               4 5 2 6 7 3 1 //postorder traversal result
   Sample output:     1
                 2        3
              4     5  6     7
   //representing the tree  


## 代码实现
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


typedef struct TreeNode* Tree;
struct TreeNode {
	int Element;
	Tree  Left;
	Tree  Right;
};

int number[100];
int index = 0;


Tree BuildTree(int inorder[], int postorder[], int N)
{
	int position = 0;
	if (N == 0) return NULL;
	struct TreeNode* T = malloc(sizeof(struct TreeNode));
	T->Element = *(postorder + N - 1);
	while (*(inorder + position) != *(postorder + N - 1))
	{
		position++;
	}
	T->Left = BuildTree(inorder, postorder, position);
	T->Right = BuildTree(inorder + position + 1, postorder + position, N - position - 1);
	return T;
}



// 层序遍历一棵树，并且保存在number数组中，tempnode数组实现类似于栈的功能
void FloorOrder(Tree T)
{
	Tree tempnode[100];
	int put_in = 0;
	int put_out = 0;
	tempnode[put_in++] = T;
	while (put_in > put_out)
	{
		if (tempnode[put_out])
		{
			number[index++] = tempnode[put_out]->Element;
			tempnode[put_in++] = tempnode[put_out]->Left;
			tempnode[put_in++] = tempnode[put_out]->Right;
		}
		put_out++;
	}
}



//打印树
void printTree(Tree T)
{
	int x = 0;
	int i = 1;
	while (i < index)
	{
		i = i * 2;
		x++;
	}
	int cengshu = x;


	x = 1;
	i = 0;
	int cur_ceng = -1;
	int start_space = cengshu + 2;
	while (i < index)
	{
		cur_ceng++;
		for (int j = 0; j < start_space; j++) printf(" ");
		while (i < x - 1)
		{
			printf("%d", number[i]);
			for (int j = 0; j < (cengshu - cur_ceng) * 2 + 1; j++) printf(" ");
			i++;
		}
		x = x * 2;
		for (int j = 0; j < start_space; j++) printf(" ");
		start_space -= 2;
		printf("\n");
	}
}


int main()
{
	Tree T;
	int inorder[10], postorder[10], N, i;

	scanf("%d", &N);
	for (i = 0; i < N; i++) scanf("%d", &inorder[i]);
	for (i = 0; i < N; i++) scanf("%d", &postorder[i]);
	T = BuildTree(inorder, postorder, N);
	printf("Check:\n");
	FloorOrder(T);

	printf("\nThe Floor order of the tree\n");
	for (int i = 0; i < index; i++)
	{
		printf("%d ", number[i]);
	}
	printf("\n");


	printTree(T);


	return 0;
}
## 运行结果
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191108165433739.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
