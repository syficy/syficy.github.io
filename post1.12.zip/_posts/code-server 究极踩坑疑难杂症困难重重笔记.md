﻿---
title: code-server疑难解决
date: 2020-01-05
tags: [docker,centos,code-server]
categories: 
- 报错解决
- code-server
---


## code-server官网命令下载很慢或无法下载
https://github.com/cdr/code-server

官方文档中的
> docker run -it -p 127.0.0.1:8080:8080 -v "${HOME}/.local/share/code-server:/home/coder/.local/share/code-server" -v "$PWD:/home/coder/project" codercom/code-server:v2

输入后无法下载或下载很慢

考虑可能是docker源的问题，笔者已经换了阿里的源，更改为网易源和官方docker-cn源后中间那段c开头的直接无法下载，于是换回阿里，在一次尝试失败后突然飞速下载，未解之谜。

## code-server 无法运行，提示权限问题

经过查找资料，应该在 run 后面加入参数 --user root  以管理员权限运行如下

>docker run --user root  -it -p 127.0.0.1:8080:8080 -v "${HOME}/.local/share/code-server:/home/coder/.local/share/code-server" -v "$PWD:/home/coder/project" codercom/code-server:v2

## code-server 容器已经运行，但是无法访问
笔者另外一个tomcat容器能够正常访问，防火墙也改过，初步排除是docker宿主机的问题，后经友人提醒docker默认只是监听0.0.0.0而不是127.0.0.1，更改如下

>docker run --user root  -it -p 0.0.0.0:8080:8080 -v "${HOME}/.local/share/code-server:/home/coder/.local/share/code-server" -v "$PWD:/home/coder/project" codercom/code-server:v2


## 无法安装python

安装python命令
>apt-get install python3
cd /usr/bin
mv python3 python

网上查到资料
V2 版本中无法在 vscode 中添加 python 配置,试用版中可以，于是这条命令继续更改如下
>docker run --user root -it -p "8080:8080" -v "/your/path/vscode/project:/home/coder/project" docker.io/codercom/code-server:2.1523-vsc1.38.1  

下面是结尾可以加的两个参数  代表允许https和password
//--allow-https --auth password


## apt-get无法下载python
换源：详见：
https://blog.csdn.net/oDeviloo/article/details/53893739
//当天下午更新，发现这个没用
因为我搞错系统了
> cd /etc
> ls
发现有个os-release的文件
打开看到是ubuntu系统而不是centos
晕倒
重来

编辑/etc/apt/sources.list
```
##中科大源

deb https://mirrors.ustc.edu.cn/ubuntu/ bionic main restricted universe multiverse
deb-src https://mirrors.ustc.edu.cn/ubuntu/ bionic main restricted universe multiverse
deb https://mirrors.ustc.edu.cn/ubuntu/ bionic-updates main restricted universe multiverse
deb-src https://mirrors.ustc.edu.cn/ubuntu/ bionic-updates main restricted universe multiverse
deb https://mirrors.ustc.edu.cn/ubuntu/ bionic-backports main restricted universe multiverse
deb-src https://mirrors.ustc.edu.cn/ubuntu/ bionic-backports main restricted universe multiverse
deb https://mirrors.ustc.edu.cn/ubuntu/ bionic-security main restricted universe multiverse
deb-src https://mirrors.ustc.edu.cn/ubuntu/ bionic-security main restricted universe multiverse
deb https://mirrors.ustc.edu.cn/ubuntu/ bionic-proposed main restricted universe multiverse
deb-src https://mirrors.ustc.edu.cn/ubuntu/ bionic-proposed main restricted universe multiverse

```

>sudo apt-get update
>sudo apt-get upgrade

终于正常了


## 成功在电脑浏览器中运行python

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191016183553685.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
## 无法打开命令行the terminal process terminated with exit code 1
使用管理员运行docker

## ipad访问概率性导致容器意外退出

未解决



## 备忘

进入 
>docker run --user root --name codetest -p 8080:8080 0a


