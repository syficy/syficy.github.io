﻿---
title: centos 使用docker 安装 anaconda+jupyter notebook，通过web访问
date: 2020-01-03
tags: [docker,centos]
categories: 
- 操作系统
- centos
---

# 查找anacond的镜像
docker search anaconda
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191113225330989.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

# 拉取镜像
docker pull continuumio/anaconda3 

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191113225642909.png)

# 运行容器
docker run -t -i continuumio/anaconda3 /bin/bash

进入内部的bash
注意此时bash中@的设备已经不一样了


# 安装notebook

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191113225729441.png)


