﻿# 使用vscode remote ssh插件公钥远程连接阿里云服务器开发python cc++

## 介绍

2019 年 5 月 3 日，在 PyCon 2019 大会上，[微软发布了 VS Code Remote](https://code.visualstudio.com/blogs/2019/05/02/remote-development)，开启了远程开发的新时代！这次发布包含了三款核心的全新插件，它们可以帮助开发者在容器、物理机器或虚拟机，以及 Windows Subsystem for Linux (WSL) 中**实现无缝的远程开发**。通过安装 Remote Development Extension Pack ，你可以快速上手远程开发。


## 本地操作

在powershell中输入ssh并且回车，显示如下代表本地open-ssh已安装，否则需要先安装。关于rsa可以参考这篇文章https://blog.csdn.net/z_qifa/article/details/74202904

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTEvYmczalBvejdCVUx0VkRPLnBuZw?x-oss-process=image/format,png) 

有可能读者之前接触过github，所以已经有了rsa，笔者在同样的情况下后期报错了，读者可以先跳过以下步骤，如果有问题，再删掉.ssh文件（默认是在用户目录下），重新建立秘钥，重新配置github等相关网站。
右键 开始菜单+A 打开powershell  输入命令  ssh-keygen -t rsa 建立秘钥
然后一路回车，会在用户目录下生成.ssh文件，里面含有公钥和私钥文件。
![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTEvaUVTUWJEM3VXOE1ZZW5rLnBuZw?x-oss-process=image/format,png)


## 控制台操作
需要在云服务器控制台开启ssh连接，并且配置安全组，（0.0.0.0：22）代表允许所有ip连接22端口，也就是ssh服务默认端口。


## 服务器操作
首先通过ssh+连接服务器,笔者使用的是mobaXterm连接的阿里云centos系统，首先要查看自己的系统是否安装了openssh 服务，如果没有需要先安装。
yum install openssh
并且开机自启
chkconfig sshd on

然后将第一步中生成的本地id_rsa.pub文件中的内容复制到centos中 /root/.ssh/authorized_keys文件中，保存并退出。

## 成功连接
首先通过powershell运行尝试是否能连接。
打开用户目录下的.ssh文件，右击空白处打开powershell，输入 ssh name@ip -i id_rsa 

如果无需密码就登入则代表成功，
如果需要密码才能登入代表rsa配置错误，可到服务器检查，
如果无法连接代表可能服务器端安全组等未打开。
如果报错：Permission denied, please try again. 代表密码或同户名错误。


## 使用VSCODE连接

打开vscode，到插件市场搜索 ‘remote ssh’ 下载插件
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTEvZ1N6MlhxZGFjdkVZQ0ZoLnBuZw?x-oss-process=image/format,png) 

然后右边就多出来了一个远程电脑的标志，点开右上角设置符号，点击加号可以快速创建

![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTEvRTJOZGV4T0dwQTFIWUtrLnBuZw?x-oss-process=image/format,png)

点击设置选第一个，如下

![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTEvZWtPanNIbW94Yk50Y3Y2LnBuZw?x-oss-process=image/format,png)

打开后输入ip  用户名 端口  路径 并且保存，就可以无需密码登入远程ssh 了

![https://i.loli.net/2019/10/11/sI6LwTzpUeQobjc.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTEvc0k2THdUenBVZVFvYmpjLnBuZw?x-oss-process=image/format,png)



## remote ssh开发python

先上图
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTEvSjc1RlZVdWFwYlRCZm9zLnBuZw?x-oss-process=image/format,png) 


点击左侧服务器标志（绿色勾代表连接成功）右边的文件夹标志，会打开一个专用的窗口，点击新建终端能够出现一个远程终端，我们新建一个python文件，然后ctrl+s保存文件，我这边保存到home目录下，然后在控制台中切换到home目录， 输入python pytnonname  运行python文件。

## remote ssh开发C/C++

在控制台输入**yum -y install gcc**
安装编译程序成功后，像python一样，我们新建一个文件，并且以Cpp为后缀名

然后输入 **g++ name.cpp -o aimname**
编译文件
然后输入./aimname 执行文件，如图

![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTEvaGFmNWdDV3c4SWpTVEh2LnBuZw?x-oss-process=image/format,png)

点击左侧应用市场可以发现服务端插件和本地插件是分开可设置的

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTEvdTdxZWNrdklDWkpNU3o2LnBuZw?x-oss-process=image/format,png) 



