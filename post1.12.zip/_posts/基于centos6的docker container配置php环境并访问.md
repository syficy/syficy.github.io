﻿## 准备工作
一台已经装好docker的主机/服务器

### 1.由于centos7存在bug ，所以我们选择基于centos6，
>docker pull centos:6

### 2.启动容器，并将container内的80端口映射到主机的1234端口,进入命令行模式。
>docker run -it -p 1234:80 id /bin/bash

### 3.安装apache
设置开机自启
启动服务

>yum install httpd
>chkconfig httpd on 
>service httpd start 

### 4 .容器中安装php
以及相关的依赖

>yum install php 
>yum install php-mysql php-gd php-imap php-ldap php-odbc php-pear php-xml php-xmlrpc

### 5，写一个简单的php代码

```PHP
<?php
	phpinfo();
?>
```

并编辑到 /var/www/html/   下

例如：
> cd /var/www/html/
> vi info.php
 
 使用ip：端口进行访问会发现不能成功显示php的info
 因为php.ini还没改，无法正常显示信息

### 6.修改php.ini

使用 php --ini 显示路径
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191019134801928.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
如上，在/etc/php.ini路径中更改，使用vi打开
然后在命令模式下用  /short  搜索到 short_open_tag中的Ofo 都改为 On
然后使用service httpd start 重启 apache服务


### 7.刷新浏览器可正常浏览php
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191019135032522.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

### 8.保存当前容器为镜像
退出或者新建一个宿主机的命令
使用docker ps 获取正在运行的容器
然后找到相应的id
使用
>docker commit  id my_php

保存镜像my_php
使用 docker images 可查看镜像

