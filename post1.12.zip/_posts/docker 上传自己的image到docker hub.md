﻿---
title: docker 上传自己的image到docker hub
date: 2020-01-06
tags: [docker]
categories: 
- 教程
---
## 保存镜像
先把容器保存为镜像
>docker commit -a "runoob.com" -m "my apache" a404c6c174a2  mymysql:v1 

其中-a后面跟着的是作者
-m后面跟着的是注释
然后是完整id
最后是自定义的镜像名字
-p是暂停

>docker images
>
可以查看到新的镜像

## 官网创建

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017212826712.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

记下此时的仓库名  name/repository name


## push镜像

打开电脑powershell 
输入docker login 登入 

然后直接push是不行的

先使用tag命令改名为上面的仓库名 例如
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017213038256.png)
是把本地的  syfcy/syfcode  改为 syfcy/server_code_py_c

然后使用push

>docker push [仓库名]

如果push的仓库是基于某个仓库的，则会直接挂载，而无需上传
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017213213890.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

