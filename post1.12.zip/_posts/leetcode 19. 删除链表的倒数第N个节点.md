﻿# leetcode 19. 删除链表的倒数第N个节点


19.删除链表的倒数第N个节点(https://leetcode-cn.com/problems/remove-nth-node-from-end-of-list/)



## 题目描述
给定一个链表，删除链表的倒数第 n 个节点，并且返回链表的头结点。

示例：

给定一个链表: 1->2->3->4->5, 和 n = 2.

当删除了倒数第二个节点后，链表变为 1->2->3->5.
说明：

给定的 n 保证是有效的。

进阶：

你能尝试使用一趟扫描实现吗？

来源：力扣（LeetCode）
链接：https://leetcode-cn.com/problems/remove-nth-node-from-end-of-list
著作权归领扣网络所有。


## 思路


用一趟扫描的话，可以定义两个指针且间隔为n，用来指向节点，当最后一个节点到NULL的时候，删除前n个节点后面的节点即可
如果tempn为NULL说明删除头结点，否则直接删除。


## 代码

```C
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     struct ListNode *next;
 * };
 */


struct ListNode* removeNthFromEnd(struct ListNode* head, int n){
    struct ListNode* temp =  head;
    struct ListNode* tempn= head;

        while(n--)
        {
            tempn = tempn->next;
        }
        if(tempn == NULL)
        {
            temp = head;
            head = head -> next;
            free(temp);
            return head;
        }
        while(tempn->next != NULL)
        {
            tempn= tempn->next;
            temp = temp->next;
        }
        tempn = temp->next;
        temp->next = temp->next->next;
        free(tempn);
    
    return head;
    
}



```



## 运行结果


执行用时 :4 ms, 在所有 c 提交中击败了85.64%的用户
内存消耗 :7 MB, 在所有 c 提交中击败了85.85%的用户


另外，手动使用free()来释放内存是比不手动使用更快的，下一行是没有使用free函数的结果

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTQvN1RkWGJKdEtqZVpDVmw2LnBuZw?x-oss-process=image/format,png) 


