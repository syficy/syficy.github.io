﻿# 爬取51job招聘信息 （一）获取城市id

[本文参考自 《实战python网络爬虫》-黄永强]
所有代码均仅用于学习，侵删
2019年10月6日代码有效

## [获取城市编号]

当我们在51job网站主页搜索python并且地区选择在浙江省时，
我们的网页**初始url**为
 https://search.51job.com/list/080000,000000,0000,00,9,99,python,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord\_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare=
去除无关参数（即去除后也可正常访问）后的**关键url**为
[https://search.51job.com/list/080000,000000,0000,00,9,99,python,2,1.html](https://search.51job.com/list/080000,000000,0000,00,9,99,python,2,1.html)
在网页F12中，对相关参数进行查找、修改访问时我们可以发现 第一串 **080000**代表为地区id
也就是城市id，那我们先找到城市id的字典。
书上说id在一个专门的js脚本中，但是19.10.6亲测已经改了，如图
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDYvQ09JaTNkQXVSMXpyV1U3LnBuZw?x-oss-process=image/format,png) 
地区字典在一个名为 *common.xxxxx.js* 的js脚本的一个函数下面定义，我们要做的就是用python脚本提取这个字典。由于网页的改动，书上的代码也要相应改变
代码如下：

```python
def get_city_code():
    url = 'https://js.51jobcdn.com/in/resource/js/2019/search/common.7331dab4.js'
    rstr = requests.get(url).text
    start = rstr.find('window.area') +12
    #print(rstr[start])
    end = rstr.find('}',start)
    #print(rstr[end])
    rrstr = rstr[start:end+1]
    #print(rrstr)
    print(type(rrstr))
    city_dict = eval(rrstr)
    print(type(city_dict))
```

其中我们先把js转化为string，再通过查找window.area和位置调整找到{，也就是字典的开始，然后从字典起点开始找}，用eval函数来将字符串转化为字典，有关这个eval函数， 经过查找得到如下用法：

 ```python
1、简单表达式
print(eval('1+2'))
输出结果：3
2、字符串转字典
print(eval("{'name':'linux','age':18}")
输出结果：{'name':'linux','age':18}
3、传递全局变量
print(eval("{'name':'linux','age':age}",{"age":1822}))
输出结果：{'name': 'linux', 'age': 1822}
4、传递本地变量
age=18
print(eval("{'name':'linux','age':age}",{"age":1822},locals()))
输出结果：{'name': 'linux', 'age': 18}
```

另外，对于书上用的split()[].split()[]的意思一开始没反应过来，后来明白，原来书上的意思是先根据第一个split由=分成多段，取第二段，再根据；分多段，取第一段，得到string版本的地区id字典，但是我这样也是根据find直接得到的string版本的字典。
贴上运行结果：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191006202955559.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)



