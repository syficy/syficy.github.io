﻿---
title: 【备忘】添加引导以使得vm和hype-v共存
date: 2020-01-01 
tags: 操作系统
categories: 
- 系统
- windows
---
详见
https://blog.csdn.net/enweitech/article/details/52180373


可能因为win10版本问题 无法运行
附带vm15：
https://blog.csdn.net/coco56/article/details/102208658
