﻿https://stackoverflow.com/questions/18972156/how-to-pass-input-to-exe-in-batch-file

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191129115425981.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
