﻿## 基操

docker中删除同id 不同tag的 image
> docker rmi res:tag

使用 CTRL+PQ退出容器是能够保存资料的，此时使用
>docker container ls -a 
会显示全部容器，包括停止的容器。

使用
>docker container start [name]
重新启动该容器

>docker container exec -it [id] bash
重新从命令行进入该容器


使用
>docker container rm [name]
删除一个容器

使用
>docker stop $(docker ps -q) & docker rm $(docker ps -aq)
一行删除全部容器



### run 中 restart 参数


docker container run ............ --restart always会在容器关闭时自动重启

--restart unless-stopped 会让容器除了外部stop命令外一直重启

--restart on-failure 会在退出容器且返回值不是0的时候重启，其实容器关闭，docker daemon重启也会重启


docker 重启会让always重启
