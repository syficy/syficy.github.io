﻿# vscode centos remote ssh java

## 服务器端安装java

参考
[https://blog.csdn.net/qq\_31800623/article/details/86764643](https://blog.csdn.net/qq_31800623/article/details/86764643)

**安装java**

yum install java-1.8.0-openjdk
安装完成后输入 java 查看是否安装成功

**安装maven**

> Maven 翻译为"专家"、"内行"，是 Apache 下的一个纯 Java 开发的开源项目。基于项目对象模型（缩写：POM）概念，Maven利用一个中央信息片断能管理一个项目的构建、报告和文档等步骤。
Maven 是一个项目管理工具，可以对 Java 项目进行构建、依赖管理。
Maven 也可被用于构建和管理各种项目，例如 C#，Ruby，Scala 和其他语言编写的项目。Maven 曾是 Jakarta 项目的子项目，现为由 Apache 软件基金会主持的独立 Apache 项目。

wget http://repos.fedorapeople.org/repos/dchen/apache-maven/epel-apache-maven.repo -O /etc/yum.repos.d/epel-apache-maven.repo

yum -y install apache-maven

安装完成后输入 mvn -v 输出版本号则安装成功




## vscode ssh连接服务器 运行java

参考
[https://blog.csdn.net/baixiaozhe/article/details/80226928](https://blog.csdn.net/baixiaozhe/article/details/80226928)


使用javac hello.java编译生成hello.class  

使用java hello来运行。

而不是java hello.class

也不是java hello.java
否则会报错【 错误: 找不到或无法加载主类 ..hello.java】





