﻿# 背景
前端开发中，网络请求的管理一直是一大重点，本文是作者对vue中网络请求的封装管理的总结。

# 请求模块
传统的ajax是基于XMLHttpRequest(XHR),但是配置混乱，编码麻烦，而jQuery确实好用但是框架太大，ue曾经推出vue-resource但是现在已经不再维护。axios是vue作者推荐的框架，也自然而然成为我们的首选。

# axios请求方式
axios(config)
axios.request(config)
axios.get(url[,config])
...

# 基本使用

安装axios框架：

```bash
npm install axios --save  //--save代表上线需要使用的模块
```

在需要使用的组件中

```bash
import axios from 'axios
```

script中

```bash
axios(config)
```
也就是

```bash
axios({
	url:'httpbin.org' //网路请求测试网站
}).then(res=>{
	console.log...
})
```
axios直接返回一个promise,可用then进行处理

# promise
promise 是 ES6 中非常重要和好用的一个特性，是异步编程的一种解决方案。常用于网络请求。

普通的js代码是自上而下的同步结果。 但是网络请求中如果同步的话会导致堵塞，js界面需要等待请求结束才能进行别的操作。

## 传统的异步解决方案
传统的异步解决方案：传入另外一个函数，当数据请求完成时将数据通过这个函数回调出去。

但是可能造成回调地域，即需要通过不断的嵌套完成多层的回调。形式上会造成代码混乱，而promise则是一种优雅的方式。

## promise异步解决方案

```javascript
//1.使用settimeout
setTimeout(()=>{
	console.log("haha")
})
```

```javascript
//promisede 的参数为函数 函数（resolve,reject）
// resolve和reject本身也是函数
new Promise((resolve,reject)=>{
	setTimeout(()=>{
	console.log("haha")
	console.log("haha")
	console.log("haha")
	console.log("haha")
		setTimeout(()=>{
		console.log("haha2")
		console.log("haha2")
		console.log("haha2")
		},1000)
}，1000)
})
```
假如我们的异步中包括异步，就会产生回调地域。

```javascript
new Promise((resolve,reject)=>{
	setTimeout(()=>{
	resolve()
	}).then()
```
这样当js运行到resolve时就会跳到.then后面的代码块

### 具体使用

1. new -> 构造函数，保存状态信息和执行传入的函数
2. 执行传入的函数（回调函数，会传入两个参数： resolve,reject，参数本身也是函数）

```javascript
new Promise((resolve,reject)=>{
fun((data)=>{处理代码}
}，1000）
```
就能变成

```javascript
new Promise((resolve,reject)=>{
fun((data)=>{
	reslove(data)	//处理代码
}
}，1000）.then((data)=>{})
```

代码从嵌套成为链式的，便于阅读理解

### reslove 与 reject


```javascript
new Promise((resolve,reject)=>{
fun((data)=>{
	reslove(data)	//处理代码，成功时
	reject('err')  //失败时，转到catch
}
}，1000）.then((data)=>{data处理}
).catch(err=>{err处理})


```


# 网络封装（最终方案）
```javascript
import axios  from 'axios'

export function request(config){
    //1.创建axios的实例
    const instance = axios.create({
        baseURL: 'http://localhost:8089',
        timeout: 5000
    })

    //发送真正的网络请求
    instance(config)
}
```

axios的基础配置比较简单，但是问题时如何优雅的调用传出的的函数，一种方式时在request中加一个参数形式的函数，然后在内部执行这个函数，但是对传参有了要求，不够优雅，所以解决方案是使用promise.
在 request.js中

```javascript
import axios  from 'axios'


export function request(config){
        //1.创建axios的实例
        const instance = axios.create({
            baseURL: 'http://localhost:8088',
            timeout: 5000
        })
        // 2.axios的拦截器
        // 2.1.请求拦截的作用
        instance.interceptors.request.use(config => {
            return config
        }, err => {
            // console.log(err);
        })

        // 2.2.响应拦截
        instance.interceptors.response.use(res => {
            return res.data
        }, err => {
            console.log(err);
        })
        window.console.log("requset2.js")
        return instance(config) //instance是一个promise
}


```

在api文件中

```javascript
import {request} from "./request";


export function loginRequest(data){
    return request({
        url:'/...',
        method: 'post',
        headers: { 'Content-Type': 'application/json' },
        data,
    })
}
```

在.vue文件中

```javascript
import///
 loginRequest(param).then(res=>{})
```

