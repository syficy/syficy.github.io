﻿项目链接
https://github.com/Siricee/hexo-theme-Chic/blob/master/README-CN.md

效果
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191020212543312.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

本人复刻效果
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019102021262153.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

右上角编辑
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191021160332676.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
