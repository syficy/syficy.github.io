﻿# leetcode 83.  删除排序链表中的重复元素


83删除排序链表中的重复元素(https://leetcode-cn.com/problems/remove-duplicates-from-sorted-list/)



## 题目描述

给定一个排序链表，删除所有重复的元素，使得每个元素只出现一次。

示例 1:

输入: 1->1->2
输出: 1->2
示例 2:

输入: 1->1->2->3->3
输出: 1->2->3

来源：力扣（LeetCode）
链接：https://leetcode-cn.com/problems/remove-duplicates-from-sorted-list
著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。


## 思路


直接判断下一个节点是否相同，否则删掉即可，注意删完不能直接下一个，不然会删不全。


## 代码

```C
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     struct ListNode *next;
 * };
 */


struct ListNode* deleteDuplicates(struct ListNode* head){
    struct ListNode* temp = head;
    struct ListNode* toFree = head;
    if(head == NULL) return head;
    while(temp->next!=NULL)
    {
        if(temp->val == temp->next->val)
        {
            toFree = temp->next;
            temp->next = temp->next->next;
            free(toFree);
        }
        else
        {
            temp = temp->next;
        }
    }
    return head;
}

```



## 运行结果
[外链图片转存失败,源站可能有防盗链机制,建议将图片保存下来直接上传(img-XBic3vX4-1571027418479)(https://i.loli.net/2019/10/14/mZjpHhiqxt1uU7D.png)]  


