﻿# 4058错误

### 情况
使用vue安装脚手架
vue cli2 install 
然乎初始化脚手架2的项目
> vue init webpack vuecli2test
> 
 运行后报错


报错如下：
>npm WARN checkPermissions Missing write access to C:......]
npm ERR! path C:...
npm ERR! code ENOENT
npm ERR! errno -4058
npm ERR! syscall access
npm ERR! enoent ENOENT: no such file or directory, access 'C:\]....
npm ERR! enoent This is related to npm not being able to find a file.
npm ERR! enoent
### 解决方案
原因是脚手架安装错误
尝试网上的删除模块重新安装方法，本机无效
使用淘宝镜像cmpn重新安装

![在这里插入图片描述](https://img-blog.csdnimg.cn/2019111812022058.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

亲测可运行

# 无法加载文件错误

## 错误情况
在powershell中使用vue ui命令时出现报错
>提示vue : 无法加载文件C:\Users\xxx\AppData\Roaming\npm\vue.ps1，因为在此系统上禁止运行脚本。有关详细信息



## 解决方案
使用该方法
https://blog.csdn.net/lihefei_coder/article/details/100522281

但是出现了新的错误
>PS C:\windows\system32> vue ui
internal/modules/cjs/loader.js:550
    throw err;
    ^

>Error: Cannot find module 'C:\Users\sheny\AppData\Roaming\npm\node_modules\vue-cli\bin\vue'
    at Function.Module._resolveFilename (internal/modules/cjs/loader.js:548:15)
    at Function.Module._load (internal/modules/cjs/loader.js:475:25)
    at Function.Module.runMain (internal/modules/cjs/loader.js:695:10)
    at startup (internal/bootstrap/node.js:201:19)
    at bootstrapNodeJSCore (internal/bootstrap/node.js:516:3)

##  Cannot find module vue-cli\bin\vue  ...at Function.Module._resolveFilename错误

解决方案：
在项目文件目录下运行
理论上可在全局下运行
具体原因未知
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191118120825363.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

## 输入vue ui后无反应
承接上个未知问题，需要安装最新的vue cli
输入 cnpm i -g @vue/cli
