﻿---
title: docker 上传自己的image到docker hub
date: 2020-01-07
tags: [docker]
categories: 
- 备忘
---

# 本地编译
笔者服务器为centos，所以本地编译要编译为能让linux运行的文件。

```bash
set GOARCH=amd64
set GOOS=linux
go build xxx.go
```
编译完会在本地目录下生成xxx的二进制文件
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200118182654808.png)

# 上传到云服务器

使用命令上传文件夹到服务器
```bash
scp  -r local_dir username@servername:remote_dir
```

# 部署准备
首先要关闭占用的端口的程序
例如笔者是更新之前的程序，使用的同样的端口，所以要关闭原有的服务，使用命令

```bash
lsof -i
```
查看笔者对应的端口![在这里插入图片描述](https://img-blog.csdnimg.cn/20200118183228603.png)
看到8089被之前的程序占用了

使用命令

```bash
kill -9 PID号
```
杀死进程


然后将新的程序赋予权限

```bash
chmod 777 filename
```

# 部署
运行文件即可，但是通过ssh连接的，当ssh终端退出时，程序也会自动停止。因此使用nohup命令,即可保持运行

```bash
nohup ./filename &
```
最后检查一下端口是否正常开启就开始本地测试吧！
