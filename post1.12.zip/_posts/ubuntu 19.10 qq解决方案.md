﻿
# 安装
先根据这篇博文安装好wine和qq
https://www.lulinux.com/archives/1319

# 中文变方块
参考
https://github.com/wszqkzqk/deepin-wine-ubuntu/issues/136

解决方案为

在

/opt/deepinwine/tools/run.sh

中将 WINE_CMD 那一行修改为

WINE_CMD="LC_ALL=zh_CN.UTF-8 deepin-wine"
