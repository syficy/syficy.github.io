﻿
参考链接【https://www.centos.bz/2017/12/linux-centos%E5%8D%87%E7%BA%A7python-3-6%E7%89%88%E6%9C%AC%E6%96%B9%E6%B3%95/】


