﻿## 查找占用端口的程序

netstat -aon|findstr "1080"

可以查到占用1080端口的程序的pid值

在任务管理器中
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191026233407976.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
右击上方空白处，选择pid，然后点击pid以大小排序，找到占用端口的程序，结束即可，并且禁止开机自启。

或者使用
>taskkill /pid 【pid值】 /f

直接结束程序

## netstat命令

### 介绍
 >netstat命令用于显示与IP、TCP、UDP和ICMP协议相关的统计数据，一般用于检验本机各端口的网络连接情况。netstat是在内核中访问网络及相关信息的程序，它能提供TCP连接，TCP和UDP监听，进程内存管理的相关报告。
### 参考
linux下：
https://www.cnblogs.com/ftl1012/p/netstat.html




## 跟踪网络命令
reacert + domin
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191026233540365.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

## 查看本机tcp/ip设置

ipconfig
windows下
https://baike.baidu.com/item/ipconfig/2496619?fr=aladdin
