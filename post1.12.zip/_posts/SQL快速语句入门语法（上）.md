﻿# SQL快速语句入门语法（一）



## 前言
搞程序是离不开数据库的，但是网上搜到的数据库教程很多都是深入介绍数据库原理的，不是说原理不重要，而是目前我的目的只是简单地进行应用，所以这篇文章来简答介绍一下数据库的语法，和操作。

使用的编译器是jetbrians家的DataGrip：
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDkvOUZwRFVxUmJMd1ZYUWRBLnBuZw?x-oss-process=image/format,png) 
不为别的，就是人性化和漂亮。
有人说搞程序要学会偷懒，这就是人性化的意义，如果不是专门做的，而是只把数据库当做一个工具，能从人的思维上去直观思考，何必一定要从机器的角度去理解。 然后要高雅的搞程序，就是得漂亮，有审美，有评委，正因如此，我选择了这款工具。

## 连接云数据库
之前注册过一个远程的云数据库，现在使用DataGrip来连接我的云数据库。
首先要在云端打开远程连接功能，以及添加相应的安全组，这一部分不清楚的可参考笔者的另外一篇博客：
[# python 外网远程连接华为云数据库增删改查](https://blog.csdn.net/qq_30600259/article/details/102260651)

打开datagrip然后进入如下菜单，新建立一个面向mysql的连接
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDkveE1nN0dUQzRWOFFQTjJuLnBuZw?x-oss-process=image/format,png) 

第一次打开时，需要在左侧打开选择MySQL并下载相应的插件，下载完成之后会出现在左侧上方【ProjectData Sources】，
输入端口，ip，用户名密码，再点击test可测试连接，确定无误，点击应用开始建立连接。
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDkva3VaRTVLVXJNRHBmWUJtLnBuZw?x-oss-process=image/format,png) 


## 数据库操作

SQL对大小写是不做区分的，结尾的冒号是用来区分多条语句的，在datagrip中ctrl+enter代表运行当前选中语句，如果没选中则给你提供选则，也可以通过设置来使得快捷键运行当前语句。设置如下： setting-General-when inside statement execute 选 Smallest statement
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191010074056570.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)


连接后，在右侧可以很方便的进行数据库操作
比如下图进行的是数据库的表修改名称，直接通过树结构找到对应的表，右击修改，在下方还会显示对应的SQL操作。

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDkvQktHSHFrTjVabXpSeThsLnBuZw?x-oss-process=image/format,png) 


下面开始命令操作

**show databases**

show databases 语句可以显示当前连接服务器有多少个数据库，并打印名称

**use【database names】**

可以选择一个数据库，并且接下来的命令默认在此数据库中运行

**show tables**

打印当前数据库的表

**creat table [name]
(
    VALUE TYPE,
    VALUE TYPE,
    VALUR TYPE
);**

创建一个数据表
下面是以上操作执行之后的结果。

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191009233147903.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)


寝室要断电了明天再跟


参考文章【[https://www.runoob.com/sql/sql-create-table.html](https://www.runoob.com/sql/sql-create-table.html)】
