﻿# python 外网远程连接华为云数据库

## 控制台准备


最近在做python爬虫的时候，涉及到数据库的内容，本来打算本地搭建一个mysql的，在安装下面软件之后
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDYvQzJaYTV5Ymh6bXZHV05pLnBuZw?x-oss-process=image/format,png) 
报出未知错误而服务无法打开，防火墙也关了，谷歌了很多方法无果，最终选择暂时搁置问题，转战华为云免费送的一个月云数据库。如下图所示，开启箭头中的远程连接和远程连接白名单，白名单设置为0.0.0.0表示为任何主机ip都可连接，这里可以各取所需，不过在下是用来学习的，安全性不是很重要，故设为全过。
点击图中左下角开启远程连接之后， 在右边会显示一个公网ip，端口默认为3306，也可据需修改。

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDYvZ0NPbmpEZldYa0tpNUU3LnBuZw?x-oss-process=image/format,png) 

然后登入，先创建一个数据库，我这边命名为test

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDYvZzNGbW9mNVVRUFRsTnFuLnBuZw?x-oss-process=image/format,png) 

ok， 控制台端操作完毕，接下来就是python代码了

## 请求端python 连接并且创建数据表

下面是用python方式建立数据库，还有另外一种语法类似sql的连接方式，读者可百度了解

```python

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer,String, DateTime
from sqlalchemy.orm import sessionmaker
#sqlalchemy是一个数据库操作模块 导入我们需要的



Base = declarative_base()
engine = create_engine("mysql+pymysql://【账号】:【密码】@【ip】:【端口】/【数据库名】",
echo = True, pool_size = 5, max_overflow = 4, pool_recycle = 7200, pool_timeout = 30)
#这是连接mysql的语句，也支持别的主流数据库连接，但是语法稍有区别，各位可百度谷歌


class mytable(Base):
    __tablename__ = 'mytable'
    id = Column(Integer,primary_key = True)
    name = Column(String(50),unique = True)
    age = Column(Integer)
    birth = Column(DateTime)
    class_name = Column(String(50))
#创建了一个名为  mytable  的类   第一行可省略 默认与类名相同
Base.metadata.create_all(engine)
#正式连接并且建立


```


下面是执行代码的控制台反馈
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191007103152664.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

下面是服务器端，可以看到新建的表了，（打开库管理-》对象列表）
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDYvN3dtWXQ4Z2xwWkR5YUhJLnBuZw?x-oss-process=image/format,png) 



## 添加数据 和 更新数据

添加数据 代码
```python
DBSession = sessionmaker(bind = engine)    #创建对象
session = DBSession()  #生成操作对象
new_data = mytable(name = 'lihua', age = 10,birth = '2018-32-2',class_name = 'yinianjiyiban') 
session.add(new_data)
session.commit() #类似于git的方案
session.close()
```
 
 **cmd端**
 ![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDYvNE81eTNvS3MxdHVCSUMyLnBuZw?x-oss-process=image/format,png) 
 
 
 **服务器端**
 
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDYvSnRDTTNPaVFCc05mYmNoLnBuZw?x-oss-process=image/format,png) 
 
 
 
**更新数据** 

```python
DBSession = sessionmaker(bind = engine)    
session = DBSession()
session.query(mytable).filter_by(id=1).update({mytable.age : 12}) #将id=1的age改为12
session.commit()
session.close()
```

**cmd端**

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDYvdXFHV01lVWRtNjNRMktGLnBuZw?x-oss-process=image/format,png) 

**服务器端**

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMDYvdUtHRmVCU1RVclhmTDhnLnBuZw?x-oss-process=image/format,png) 


## 查询数据

**查找打印全部**

```python
DBSession = sessionmaker(bind = engine)    
session = DBSession()
get_data = session.query(mytable).all()
for i in get_data:
    print('我的名字是：' + i.name)
    print('我的班级是：' + i.class_name)
session.close()
```


**多条件删选**

```python
get_data = session.query(mytable).filter(mytable.id>=2,mytable.class_name=='201').first()
print('我的名字是' + get_data.name)
```

其中filter与filter_by的区别是前者可以带表名查找
fisrt可以返回第一个 all返回所有以列表形式

当然也可以直接执行sql语法形式的 但是我困了





