﻿# 分享一个利用零宽字符和摩斯电码加密的github项目

项目链接：
https://github.com/rover95/morse-encrypt?tdsourcetag=s_pcqq_aiomsg

###应用
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015084548666.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

字符【哈哈哈哈】 在电脑QQ输入框是这样的
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015084651681.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
发送后是这样的：

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015084723741.png)

QQ手机端可能会丢失零宽字符。

在CSDN的md编辑器中
字符【哈哈‌‍‍‌‍​‌‌‍​‍‍‌‌‌​‌‌‍‌​‌‍‍‍‍​‍‌‌‌‌​‌‍‍‌‍​‌‌‍​‍‍‌‌‌​‌‍​‍‍‍‍‍​‍‌‌‌​‌‍‍‌‍​‌‌‍​‍‌‌‌‌​‌‌‍‍‍​‍‍‍‌‌​‍‍‍‍‍​‌‍‍‌‍​‌‌‍​‍‌‌‌‌​‍‍‌‌‌​‌‌‍‍‍​‌‌‍‌​‌‍‍‌‍​‌‌‍​‌‌‌‌‍​‌​‌‍​‌‌‌‌‍​‌‍‍‌‍​‌‌‍​‍‌‌‌‌​‍‌‌​‌‌‌‌‍​‌‍‍‍‍​‌‍‍‌‍​‌‌‍​‌‌‌‌‍​‌​‌‌‍‍‍​‍‌‌​‌‍‍‌‍​‌‌‍​‌‌‌‌‌​‌‌‍‌​‍‌‍‌​‌‌‌‍‍​‌‍‍‍‍​‍‌‌‌‌​‍‍‌‌‌​‍‍‍‍‌​‍‍‍‍‌​‍‍‍‌‌​‍‌‌‌‌​‌‌‌‌‌​‌‌‍‍‍哈哈】占用接近500个字符。



图一
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015084848253.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
图二
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015084942181.png)



这是一种较好的隐藏信息传送方式


## 不足
该项目无法加密【.】【、】等标点符号。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015085154300.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
