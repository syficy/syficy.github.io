﻿---
title: centos 配置docker
date: 2020-01-04
tags: [docker,centos]
categories: 
- 操作系统
- centos
---

# centos 配置docker

## 安装依赖包
> yum install -y yum-utils device-mapper-persistent-data lvm2
> rpm -qa|grep device-mapper-persisent-data
> rpm -qa|grep lvm2

## 配置yum源
> yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
> yum makecache fast
## 安装
> yum list docker-ce.x86_64 --showduplicates | sort -r  查看可安装版本
> yum install docker-ce -y     -y代表全选yes

视网络情况等待，我等了大约10分钟。

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015181222967.png)

安装成功，输入docker version 显示版本信息，其中有docker版本和go语言版本

## 启动
>systemctl start docker //启动
>systemctl enable docker //开机自启
>systemctl status docker //状态查看

再次输入docker version 显示版本信息
显示两个版本，一个是服务端，一个是客户端，开始时一样的。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015181422915.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)



## 配置镜像加速
使用阿里云容器镜像加速服务，详情见
https://cr.console.aliyun.com/cn-hangzhou/instances/mirrors


## 基础docker操作
>docker seacher "name"
直接搜索，会显示火热度，是否官方版本。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015181830127.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)


>docker image  显示本地镜像

>docker search [name]  搜索

>docker pull [java]:[8]  下载指定版本的某

>//docker -rmi [id]or[name]
>docker image rm [imageName]   删除某image

>docker inspect [name] 查看原信息

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015212733245.png)
可见一个java的镜像有643mb，但是jdk一般在200mb左右，原因是该镜像基于一个基础镜像，分层结构


## 特性

运行一个镜像就是一个容器，容器与容器之间相互隔离，相互不影响


## 容器操作

安装tomcat之后
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015213532744.png)

>docker run --name tom -p 80:8080 -d tomcat:latest

其中run 代表运行  --name tom 取名  将容器中的80端口映射到8080端口 -d是背后运行，不阻塞宿主机  最后是镜像名也可以用id。

然后回出现一个日志

使用 
>docker logs 【name】 查看日志

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015213950997.png)

进入
>docker exec -it tom /bin/bash
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019101521564416.png)

退出
> exit

查看运行的容器
>docker ps

删除容器
>docker rm -f tom

