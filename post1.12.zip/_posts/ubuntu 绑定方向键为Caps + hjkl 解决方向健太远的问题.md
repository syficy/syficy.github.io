﻿# 背景
做开发的时候，尤其是博主在写前端代码时，各种ide代码提示十分完善，但是这也带来了需要时常使用方向键去调整位置，然后方向键盘在键盘核心区域之外，因此有诸多不便，windows下博主使用的是hotkey的代码映射功能，把caps和hjkl的组合映射为方向键，方便不少。ubuntu下由于vi的关系，网上很多教程把esc和caps两键互换，也能方便很多，但是博主已经习惯了61键键盘的caps和hjkl组合，所以换成ubuntu时，寻求代替windows的hotkey的功能替代。

# 工具
ubuntu 19.10测试无误 其他版本应该没大问题
xmodmap 博主系统是自带装好的
终端运行 

```
xmodmap
```
提示无误则安装过
否则安装

```
sudo apt install xmodmap
```

# 步骤
### 1. 创建配置文件

```
vim ~/.xmodmap
```

### 2. 修改配置文件

将上述配置文件内容改为：
```
keycode 66 = Mode_switch
keysym h = h H Left
keysym l = l L Right
keysym k = k K Up
keysym j = j J Down
```

### 3. 运行配置
xmodmap ~/.xmodmap






参考：https://unix.stackexchange.com/questions/414926/bind-capshjkl-to-arrow-keys-caps-to-esc
