﻿# 爬取51job招聘信息 （二）获取页数和职位信息

[本文代码参考自 《实战python网络爬虫》-黄永强 2019.6月版本]
为保证时效性 对原书代码有较大修改 本文代码2019年10月7日有效
所有代码程序均仅用于学习，若无意伤害了您的个人利益请速与我联系删除

## [获取总页数]
上一节中我们已经获得了城市id，接下去就是通过城市id获取页数，以便后期爬取。
```python

def get_pageNumber(city_code, keyword):
    url = 'https://search.51job.com/list/' + str(city_code) + ',000000,0000,00,9,99,'+str(keyword)+',2,1.html'
    
    #driver = webdriver.Chrome()
    #driver.get(url)
    #os.system("pause")
    
    r = requests.get(url, headers = headers)
    soup = BeautifulSoup(r.content.decode('gbk'),'html5lib')
    find_page = soup.find('div',class_ = 'rt').getText()
    find_page = find_page[5::]
    print(find_page)
    temp = re.search('\d+\.?\d*',find_page).group()
    print(int(temp))
    if temp:
        pageNumber = math.ceil(int(temp)/50)
        return pageNumber
    else:
        return 0


```
    
使用beautifulsoup模块，经过gbk解码 html5lib 后得到的 soup 在其中找到带rt class的 div  中可得到职位总数，其中，gbk可在页面的响应头中得到，在通过数据处理除去每页50得到结果，也可以直接使用下方的页面数，但是职位为0的时候页面数也会显示1，所以需要更多处理。
math.seil 即 天花板， 把数字往大了放， 同理math.floor 是把数字往小了放。


## [获取页面]

我们可以发现1.html前的那个参数代表第几个页面，因此通过修改这个值可以获得不同的url，在通过beautifulsoup净化之后，在页面的p标签中得到50个详情url，然后尝试遍历这50个url的信息，得到我们要的职位详情。

```python

def get_page(keyword,pageNumber):
    for p in range(int(pageNumber)):
        url = 'https://search.51job.com/list/' + str(city_code) + ',000000,0000,00,9,99,'+str(keyword)+',2,'+str(p+1)+'1.html'
        r = requests.get(url,headers=headers)
        soup = BeautifulSoup(r.content.decode('gbk'),'html5lib')
        find_p = soup.find_all('p',class_=re.compile('t1'))
        print(find_p)
        for i in find_p:
            try:
                info_dict = None
                print(i.find('a')['href'])
                url = i.find('a')['href']
                info_dict = get_info(url)
                print(info_dict)
                if info_dict:
                    insert_db(info_dict)
            except Exception as e:
                print(e)
                time.sleep(5)

```


## [获取职位详情]

由于有些职位详情页面不是51job的，所以我们要先判断是否为51job页面，否则无法使用相同的语法进行提取，我们先跳过这一部分职位。同样的美化我们的新详情url，并用一个字典存储我们想要的所有信息。

```python

def get_info(url):
    temp_dict = {}
    if 'https://jobs.51job.com' in url:
        r = requests.get(url, headers=headers)
        time.sleep(1.5)
        soup = BeautifulSoup(r.content.decode('gbk'), 'html5lib')
        temp_dict['job_id'] = url.split('.html')[0].split('/')[-1]
        temp_dict['company_name'] = soup.find('a', class_='catn').getText().strip()
        com_tag = soup.find('div', class_='com_tag').find_all('p')
        for i in com_tag:
            if 'i_flag' in str(i):
                temp_dict['company_type'] = i.getText()
            if 'i_people' in str(i):
                temp_dict['company_scale'] = i.getText()
            if 'i_trade' in str(i):
                temp_dict['company_trade'] = i.getText()
        temp_dict['job_name'] = soup.find('h1').getText().strip()
        temp_dict['job_pay'] = soup.find('div', class_='cn').find('strong').getText().strip()
        msgltype = soup.find('p', class_='msg ltype').getText().split('|')
        education = ['初中', '中专', '中技', '大专', '高中', '本科', '硕士', '博士']
        if msgltype:
            for i in msgltype:
                if '经验' in i.strip():
                    temp_dict['job_years'] = i.strip()
                elif '人' in i.strip():
                    temp_dict['job_member'] = i.strip()
                elif '发布' in i.strip():
                    temp_dict['job_date'] = i.strip()
                elif i.strip() in education:
                    temp_dict['job_education'] = i.strip()
        t1 = soup.find('div', class_='t1').find_all('span')
        welfare = []
        for i in t1:
            welfare.append(i.getText().strip())
        temp_dict['company_welfare'] = '/'.join(welfare)
        bmsg = soup.find('div', class_='bmsg inbox')
        if bmsg:
            if bmsg.find('p', class_="fp"):
                temp_dict['job_location'] = bmsg.find('p', class_="fp").getText().strip()
        find_describe = soup.find('div', class_='bmsg job_msg inbox')
        temp = str(find_describe).split('<div class="mt10">')[0]
        Mysoup = BeautifulSoup(temp, 'html5lib')
        temp_dict['job_describe'] = Mysoup.getText().strip()
        temp_dict['recruit_sources'] = '前程无忧'
        return temp_dict

```



