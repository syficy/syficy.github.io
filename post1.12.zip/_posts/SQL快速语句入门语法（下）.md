﻿# SQL快速语句入门语法（下）



## 前言
接上文。[SQL快速语句入门语法（上）](https://blog.csdn.net/qq_30600259/article/details/102472159)



## 数据库操作

**insert插入语句**

主要有两种形式

第一种是直接插入表中，但是要保证所有列都有数据。
```sql
INSERT INTO table_name
VALUES (value1,value2,value3,...);
```
第二种是指定插入哪些列中，其中没有被插入的列值指定为NULL。
```sql
INSERT INTO table_name(column1,column2,column3,...)  
VALUES (value1,value2,value3,...);
```

以下是实例：
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTAvSmczN1Ayc0ZRR0lTcnduLnBuZw?x-oss-process=image/format,png) 



**update更新语句**

```sql
UPDATE table_name
SET column1=value1,column2=value,...  
WHERE some_column=some_value;
```

以下是实例截图：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191010170836889.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

这个update命令是饱和的，比如我有两项的姓名都是‘KI’，执行命令时都会更改：
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTAvY1pvMnBROVBCZDRNOHRpLnBuZw?x-oss-process=image/format,png) 



**DELETE删除语句**

```SQL
DELETE FROM table_name  
WHERE some_column=some_value;
```

与update一样，delete也是饱和的删除。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191010170855868.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

**order by 排序语句**

```SQL
SELECT column\_name,column\_name  
FROM table\_name 
ORDER BY column\_name,column\_name ASC|DESC;
```

其中asc是升序，desc是降序，默认是升序的
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTAvcUU0TnVkdGVJRjVsQW82LnBuZw?x-oss-process=image/format,png) 

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191010170915422.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)


也可以多行使用，如下是先根据money列降序排列，再根据id列降序排列。
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTAveElrQzdhYmp0RjZlTGdmLnBuZw?x-oss-process=image/format,png) 




**AND&OR**
如果第一个条件和第二个条件都成立，则 AND 运算符显示一条记录。
如果第一个条件和第二个条件中只要有一个成立，则 OR 运算符显示一条记录。
![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTAvOGVZZkZpYjV4a1RRT2d0LnBuZw?x-oss-process=image/format,png) 

![image.png](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pLmxvbGkubmV0LzIwMTkvMTAvMTAvdEVCbFhXcU4zT3hrQzVNLnBuZw?x-oss-process=image/format,png) 



