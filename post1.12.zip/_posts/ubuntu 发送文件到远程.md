﻿最近在基于ubuntu的docker的容器中运行了code-server的web版vs-code，然而由于ipad浏览器的限制，导致文件可能因为容器的崩溃或者服务器主机的各种意外情况而丢失，所以我需要一个方案来快速保存我的这些代码。

## 思路1：将文件直接置于其他服务器

然而web端vscode支持插件少之又少，不能像主机上的一样正常使用remote-ssh插件


## 思路2：使用scp手动传送文件

scp 是 linux 系统下基于 ssh 登陆进行安全的远程文件拷贝命令，是加密的rcp。

语法：

>scp 文件目录  ip：文件目录

然后需要输入密码即可传送

如需传送整个文件夹，只需要加上-r 比如下面这个传送当前文件夹所有文件

>scp -r . 0.0.0.0:xxx

## 思路3: 基于ftp/sftp的curl

curl是一种命令行工具，支持多种协议，作用是发出网络请求，然后得到和提取数据，
基于ftp的话
首先要把ftp地址转化为url
ftp://[name]:[password]@ip:post/[mulu]

然后使用
>curl -T “file.name” ftp_url

参考：https://www.cnblogs.com/linjiqin/p/5484910.html
