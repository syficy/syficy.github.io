﻿# 背景
笔者笔记本由于种种原因，触摸板无法使用，而笔者又恰恰是无线生活的热爱者，出门在外要是突然不小心关闭了电脑的蓝牙或者打开了飞行模式就惨了，因为这就意味着需要在不动鼠标的情况下打开蓝牙。在windows下可以通过不断的tab和方向键以及空格键找到开启蓝牙的地方，而ubuntu当然有更万能的手段--终端。

# 环境
ubuntu 19.10

# 步骤
### 1. 打开蓝牙软件锁
通过ctrl+alt+t打开一个终端，输入rfkill list 可以看到射频设备的情况
```bash
rfkill list
0: ideapad_wlan: Wireless LAN
	Soft blocked: no
	Hard blocked: no
1: ideapad_bluetooth: Bluetooth
	Soft blocked: no
	Hard blocked: no
2: phy0: Wireless LAN
	Soft blocked: no
	Hard blocked: no
3: hci0: Bluetooth
	Soft blocked: no
	Hard blocked: no
```

如果开启了飞行模式或者是关闭了蓝牙，会有yes显示，这时候就需要使用 rfkill unblock all命令把所有的设备打开（也可以只开启一个）

### 2. 开启蓝牙设备
终端输入 hciconfig 命令确认蓝牙设备被系统所识别，然后输入 
```bash
 hciconfig hci0 up
```
以启用蓝牙
然后输入

```bash
bluetoothctl
```
大多数情况下已经可以自动连接上之前连上的设备了，如果不行或着你恰好鼠标炸了急着想换个新鼠标，则进行第三步。

### 3.蓝牙扫描连接
输入scan on
 启动搜索模式
 然后搜到目标设备就输入 scan off 停止探索
 复制（当然没有鼠标的情况下不方便复制就慢慢输入）目标设备的mac地址，输入
 

```bash
pair xx.xx.xx.xx.xx.xx
```

然后配对成功

再输入
```bash
connect xx.xx.xx.xx.xx.xx
```

显示successful则成功
