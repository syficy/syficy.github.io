﻿# vscode 插件备忘录

## 远程
远程开发:
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191014181220828.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
>从原理上讲，VSCode 远程开发扩展相当于把开发者自己机器上的 VSCode 原样拷贝到作为目标机器（Remote Host）上，以服务的形式运行，而本地的 VSCode 作为客户端，两者之间通过远程通讯协议彼此协调合作，实际上的开发工作主要是在服务端完成的。这个架构特别之处在于，我们日常所使用的扩展也被分成两个阵营：和界面定制相关的部分，主要包括样式、主题、图标等等在客户端运行；而与开发相关的大部分扩展则在服务端运行。
>[引用自https://juejin.im/entry/5d02628d518825259c03381f]

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191014181912299.png)

## C、C++

C/C++
C/C++ Clang Command Adapter 提供静态检测（Lint）
Code Runner
Include Autocomplete：提供头文件补全
C/C++ Snippets：Snippets 重用代码块

## java

Java Extension Pack


参考 
https://www.infoq.cn/article/wSaK-Nm2ZhK65ydrUdgJ
