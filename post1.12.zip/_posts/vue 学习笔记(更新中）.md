﻿# 解析步骤
如图
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191103203037701.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

vue是响应式的，代码逻辑在前11行还是正常html内容，后面再调用vue类对前面的html进行修改。


# mustache 语法
中文译为 胡须， 即双大括号。

# 插值语法

### 代码
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>


<div id="app">
  {{message}}
  <h2>{{message}},hello</h2>
  <h2>{{firstname +' ' + lastname}}</h2>
  <h2>{{firstname}}{{" "}}{{lastname}}</h2>
  <h2>{{counter*2}}</h2>
</div>


<script src="../js/vue.js"></script>
<script>
  const app = new Vue({
    el : "#app",
    data:{
      message:"hello world",
      firstname:"shen",
      lastname: "yufan",
      counter:100
    }
  })
</script>

</body>
</html>
```

### 实现效果
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191104090424987.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

# v-once
可以将响应式改为不响应
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019110409113699.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

# v-html
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191104092447683.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

# v-text
不常用
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191104092638364.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

# v-pre

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Title</title>
</head>
<body>

<div id="app">
  {{message}}
  <h2 v-pre>{{message}}</h2>
</div>


<script src="../js/vue.js"></script>
<script>
  const app = new Vue({
    el : "#app",
    data:{
      message:"hello world"
    }
  })
</script>

</body>
</html>
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191104092809545.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

# v-cloak
cloak翻译为斗篷
vue解析后删去，因此可在head中操作该属性以实现渲染前后的效果
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <style>
  [v-cloak]{
    display:none;
  }
  </style>
</head>
<body>

<div id="app" v-cloak>
  {{message}}
</div>


<script src="../js/vue.js"></script>
<script>

  // 在vue解析之前有属性v-cloak 解析之后就没有了
  setTimeout(function() {
    const app = new Vue({
      el: "#app",
      data: {
        message: "hello world"
      }
    })
  },1000)
</script>


</body>
</html>
```

如果没有c-cloak则会先显示原始标签一秒后解析
使用了就会不显示等解析

# v-bind
mustache 用于内容content的指定修改，但不能用于属性值修改
v-bind可以动态绑定属性

```html
  <img v-bind:src="imgURL" alt="">
```

```javascript
  const app = new Vue({
    el : "#app",
    data:{
      message:"hello world" ,
      imgURL:"https://"
    }
  })
```

由于语法糖语法也可以这么写（省略v-bind）：
```html
  <img :src="imgURL" alt="">
```

# 动态绑定css 以及数组写法
```html

<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
</head>
<body>
<div id="app">
  <!--<h2 :style="{key(属性名)：value(属性值)"></h2>-->
  <!--<h2 :style="{fontSize: '50px'}">{{message}}</h2>-->
  <h2 :style="getStyles()">{{message}}</h2>
  {{message}}
</div>


<script src="../js/vue.js"></script>
<script>
  const app = new Vue({
    el : "#app",
    data:{
      message:"hello world!",
      finalsize: '180',
      finalcolor: 'red'
    },
    methods:{
      getStyles: function(){
        return{fontSize: this.finalsize + 'px',backgroundColor:this.finalcolor,color:'green'}
      }
    }
  })
</script>
</body>
</html>

```

数组写法：
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Title</title>
</head>
<body>
<div id="app">
  <h2 :style="[basestyle,basestyle1]">{{message}}</h2>
  {{message}}
</div>


<script src="../js/vue.js"></script>
<script>
  const app = new Vue({
    el : "#app",
    data:{
      message:"hello world",
      basestyle:{backgroundColor:'red'},
      basestyle1:{fontSize:'100px'},
    }
  })
</script>
</body>
</html>
```


# 计算属性

代码:
computed属性
返回值：function(){
shixian
return xxx}


```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Title</title>
</head>
<body>


<div id="app">
  <h2>总价格: {{totalprice}}</h2>
</div>


<script src="../js/vue.js"></script>
<script>
  const app = new Vue({
    el : "#app",
    data: {
      books: [
        {id: 110, name: 'unixb', price: 110},
        {id: 111, name: 'unixd', price: 115},
        {id: 112, name: 'nixc', price: 21},
        {id: 113, name: 'ua', price: 10},
      ]
    },
    computed:{
      totalprice: function(){
        // 还有部分函数
        let result = 0
        for(let i=0;i<this.books.length;i++)
        {
          result+= this.books[i].price
        }
        return result
      }
    }
  })
</script>


</body>
</html>
```


# 回调参数
分页组件“el-pagination”的文档中显示的current-page参数一直在想办法获取，实则为回调参数。记住回调参数和回调函数的概念。

https://www.zhihu.com/question/19801131
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200119141933747.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
# axios

```javascript
const param = `userId=${user.userId}&property=0&page=${this.currentPagesData}&per=10`
```
使用${}来表示变量，不用拼接啦

