﻿
# [Problem 1]:
### (1) Task description: 
Implement functions of the array based list, and then write a program to create an array list based on user input data, and then print out the list.
### (2) Method: 
Structure a number array, and use a integer value to represent the max length, then all the operations are based on the number array.

### (3) Implementation: 
```c
main.c


// Powered by 沈宇帆， student ID ：2018329621232

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "arraylist.h"

int main(int argc, char* argv[])
{
	int x_input = 1;
	List Llist = NULL;
	int  AList_rear= 0;
	Llist = MakeEmpty(Llist);
	printf("Please input some integer values to create the list, input 0 for exit!\n");
	while (x_input != 0)
	{
		scanf("%d", &x_input);
		Insert(x_input, Llist, AList_rear);
		AList_rear++;
	}



    // The code to show functions
	printf("%d  (0 is not empty, 1 is empty)\n", IsEmpty(Llist));
	printf("%d  (0 is not full, 1 is full)\n", IsFull(Llist));

	printf("print the list:\n");
	PrintList(Llist);
	printf("delete number 3:\n");
	Delete(3, Llist);
	PrintList(Llist);
	printf("the last of list is %d\n", GetLastValue(Llist));
	printf("the first of list is %d\n", First(Llist));
	Delete(GetLastValue(Llist), Llist);
	printf("Using the function to delete the last value:\n");
	PrintList(Llist);
	printf("the size of the list is : %d\n", Size(Llist));
printf("the position of the previous of the number 4 is : %d\n", FindPrevious(4,Llist));

	return 0;
}


arraylist.h

#define Max_Size 100
typedef int ElementType;


        #ifndef _ArrayList_H
        #define _ArrayList_H

        struct AList;
        typedef struct AList *List;

        List MakeEmpty( List L );
        int IsEmpty( List L );
        int IsLast( int p);
        int Find( ElementType X, List L );
        void Delete( ElementType X, List L );
        int FindPrevious( ElementType X, List L );
        void Insert( ElementType X, List L, int P );
        void DeleteList( List L );
        int First( List L );
        int Advance( int P );
        ElementType Retrieve( int P,List L );
        ///////////////////////////////////////////
        int IsFull(List L);
        ElementType GetLastValue(List L);
		int GetLastPosition(List L);
        int Size(List L);
        void PrintList(List L);

        ///////////////////////
      struct AList{
	ElementType data[Max_Size];
	int length;
};
       ////////////////////////


        #endif    /* _linklist_H */
/* END */


arraylist.c
// Powered by 沈宇帆， student ID ：2018329621232  using Visual Studio

#define Max_Size 100
typedef int ElementType;
#include "arraylist.h"
#include <stdlib.h>
#include "fatal.h"


        typedef struct AList *List;

		void DeleteList(List L)
		{
			free(L);
		}
		List MakeEmpty(List L)
		{
			if (L != NULL)
				DeleteList(L);
			L = (List)malloc(sizeof(struct AList));
			if (L == NULL)
				FatalError("Out of memory!");
			L->length = 0;
			return L;
		}
		int IsEmpty(List L)
		{
			if (L->length == 0) return 1;
			else return 0;
		}
		int IsLast(int p,List L)
		{
			if (L->length-1 == p) return 1;
			else return 0;
		}
		int Find(ElementType X, List L)
		{
			for (int i = 0; i < L->length; i++)
			{
				if (L->data[i] == X)
				{
					return i+1;
				}
			}
			FatalError("Error  Cannot find!!!");
			return -1;
		}
		void Delete(ElementType X, List L)
		{
			if (L->length == 0)
			{
				FatalError("Error no element!!!");
			}
			for (int i = 0; i < L->length; i++)
			{
				if (L->data[i] == X)
				{
					for (int j = i; j < L->length; j++)
					{
						L->data[j] = L->data[j + 1];
					}
					L->length--;
					return;
				}
			}
			FatalError("Error  Cannot find!!!");
			return;
		}
		int FindPrevious(ElementType X, List L)
		{
			if (L->length < 2)
			{
				FatalError("Error no previous!!!");
			}
			for (int i = 0; i < L->length; i++)
			{
				if (L->data[i] == X)
				{
					return i;
				}
			}
			FatalError("Can't found");
		}
		void Insert(ElementType X, List L, int P)
		{
			if (L->length + 1 > Max_Size)
			{
				FatalError("Out of Size!!!");
				return;
			}
			for (int j = L->length; j > P; j--)
			{
				L->data[j] = L->data[j - 1];
			}
			L->data[P] = X;
			L->length++;
			return;
	
		}
		int First(List L)
		{
			return L->data[0];
		}
		int Advance(int P,List L)
		{
			return L->data[P];
		}
		ElementType Retrieve(int P, List L)
		{
			return L->data[P - 1];
		}
        ///////////////////////////////////////////
		int IsFull(List L)
		{
			if (L->length == Max_Size)
				return 1;
			else return 0;
		}
		ElementType GetLastValue(List L)
		{
			return L->data[L->length - 1];
		}
		int GetLastPosition(List L)
		{
			return L->length - 1;
		}
		int Size(List L)
		{
			return L->length;
		}
		void PrintList(List L)
		{
			if (IsEmpty(L)) printf("empty!");
			for (int i = 0; i < L->length; i++)
			{
				printf("%d ", L->data[i]);
			}
			printf("\n");
		}


        ///////////////////////

       ////////////////////////


         /* _linklist_C */
/* END */



fatal.h
#include <stdio.h>
#include <stdlib.h>

#define Error( Str )        FatalError( Str )
#define FatalError( Str )   fprintf( stderr, "%s\n", Str ), exit( 1 )

```


# Problem 2

### (1) Task description:
Implement a desk calculator, expression may include the parenthesis and the exponentiation operator. Added, my program also can calculate the floating point number , and deal with the exponentiation operator.

### (2) Methods:
1. Using the Stack to transform an infix expression to postfix expression, and then using an other Stack to calculate the result from postfix expression.
2. When the user input, using the space key to divide the expression, and using dot to judge the floating point number, if it is number, save it in a char[], then use the function “itof” to transform it to a number. Use “=” to judge the inputting is end.

### (3) Implementation:
```c
main.c


// Powerd by 沈宇帆 ， student ID = 2018329621232 ， using Visual Studio



#include "stackli.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int isNumber(char a)
{
	if (a >= '0' && a <= '9') return 1;
	else return 0;
}


int Priority(char a)
{
	if (a == '(' || a == ')') return 5;
	else if (a == '^') return 4;
	else if (a == '*' || a == '/') return 3;
	else if (a == '+' || a == '-') return 2;

}



int main()
{
	Stack S_postfix_to_ans,S_infix_to_postfix;
	S_postfix_to_ans = CreateStack();
	S_infix_to_postfix = CreateStack();

	char number_string[100000];
	char Formula[1000];
	int Number_itor = 0;
	double su1;
	double su2;
	char a;
	int Formulla_rear = 0;
	scanf("%c", &a);
	while (1)
	{
		
		if (isNumber(a) || a == '.')
		{
			Formula[Formulla_rear] = a;
			Formulla_rear++;
		}
		else if (a == ' ')
		{
			Formula[Formulla_rear] =' ';
			Formulla_rear++;
		}
		else if (a == '=')
		{
			while (!IsEmpty(S_infix_to_postfix))
			{
				Formula[Formulla_rear] = Top(S_infix_to_postfix);
				Formulla_rear++;
				Formula[Formulla_rear] = ' ';
				Formulla_rear++;
				Pop(S_infix_to_postfix);
			}
			Formula[Formulla_rear] = '=';
			break;
		}
		else
		{
			if (a == ')')
			{
				while (Top(S_infix_to_postfix) != '(')
				{
					Formula[Formulla_rear] = Top(S_infix_to_postfix);
					Formulla_rear++;
					Formula[Formulla_rear] = ' ';
					Formulla_rear++;
					Pop(S_infix_to_postfix);
				}
				Pop(S_infix_to_postfix);
				scanf("%c", &a);
			}
			else if (a == '^')
			{
				while (!IsEmpty(S_infix_to_postfix) && Priority(Top(S_infix_to_postfix)) > Priority(a))
				{
					if (Top(S_infix_to_postfix) == '(') break;
					Formula[Formulla_rear] = Top(S_infix_to_postfix);
					Formulla_rear++;
					Formula[Formulla_rear] = ' ';
					Formulla_rear++;
					Pop(S_infix_to_postfix);
				}
				Push(a, S_infix_to_postfix);
				scanf("%c", &a);
			}
			else
			{
				while (!IsEmpty(S_infix_to_postfix) && Priority(Top(S_infix_to_postfix)) >= Priority(a))
				{
					if (Top(S_infix_to_postfix) == '(') break;
					Formula[Formulla_rear] = Top(S_infix_to_postfix);
					Formulla_rear++;
					Formula[Formulla_rear] = ' ';
					Formulla_rear++;
					Pop(S_infix_to_postfix);
				}
				Push(a, S_infix_to_postfix);
				scanf("%c", &a);
			}
		}
		scanf("%c", &a);
	}


	printf("The postfix formulla : \n", Formulla_rear);
	for (int i = 0; i <= Formulla_rear; i++)
	{
		printf("%c", Formula[i]);
	}
	printf("\n");




	int Formula_itor = 0;
	a = Formula[Formula_itor];
	for (int i = 0; i <= Formulla_rear; i++)
	{

		while (a != '=')
		{
			if (isNumber(a) || a == '.')
			{
				number_string[Number_itor] = a;
				Number_itor++;
				number_string[Number_itor] = ' ';
			}
			else if (a == ' ')
			{
				double tempS = atof(number_string);
				Number_itor = 0;
				Push(tempS, S_postfix_to_ans);
			}
			else if (a == '=')
			{
				break;
			}
			else
			{
				if (a == '+')
				{
					su2 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					su1 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					double tempR = su1 + su2;
					Push(tempR, S_postfix_to_ans);
				}
				else if (a == '-')
				{
					su2 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					su1 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					double tempR = su1 - su2;
					Push(tempR, S_postfix_to_ans);
				}
				else if (a == '*')
				{
					su2 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					su1 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					double tempR = su1 * su2;
					Push(tempR, S_postfix_to_ans);
				}
				else if (a == '/')
				{
					su2 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					su1 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					if (abs(su2 - 0) < 0.0000001)
					{
						printf("\nERROR!The divisor cannot be 0!\n");
						exit(-1);
					}
					double tempR = su1 / su2;
					Push(tempR, S_postfix_to_ans);
				}
				else if (a == '^')
				{
					su2 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					su1 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					double tempR = 1;
					for (i = 0; i < su2; i++)
					{
						tempR *= su1;
					}
					Push(tempR, S_postfix_to_ans);
				}


				Formula_itor++;
				a = Formula[Formula_itor];
			}
			Formula_itor++;
			a = Formula[Formula_itor];
		}
	}

	printf("\nans = %lf\n", Top(S_postfix_to_ans));


	/*
	Direct input postfix expression
	
	while (1)
	{



		printf("Please input the poatfix and Separated by spaces in one line, use ' =' to end and enter the Enter key\n");
		scanf_s("%c", &a);
		while (a != '=')
		{
			if (isNumber(a) || a == '.')
			{
				number_string[Number_itor] = a;
				Number_itor++;
				number_string[Number_itor] = ' ';
			}
			else if (a == ' ')
			{
				double tempS = atoi(number_string);
				Number_itor = 0;
				Push(tempS, S_postfix_to_ans);
			}
			else if (a == '=')
			{
				break;
			}
			else
			{
				if (a == '+')
				{
					su2 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					su1 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					double tempR = su1 + su2;
					Push(tempR, S_postfix_to_ans);
				}
				else if (a == '-')
				{
					su2 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					su1 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					double tempR = su1 - su2;
					Push(tempR, S_postfix_to_ans);
				}
				else if (a == '*')
				{
					su2 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					su1 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					double tempR = su1 * su2;
					Push(tempR, S_postfix_to_ans);
				}
				else if (a == '/')
				{
					su2 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					su1 = Top(S_postfix_to_ans);
					Pop(S_postfix_to_ans);
					if (abs(su2 - 0) < 0.0000001)
					{
						printf("ERROR!The divisor cannot be 0!\n");
						exit(-1);
					}
					double tempR = su1 / su2;
					Push(tempR, S_postfix_to_ans);
				}
				scanf_s("%c", &a);
			}
			scanf_s("%c", &a);
		}
		printf("ans = %lf\n", Top(S_postfix_to_ans);
		scanf_s("%c", &a);



		if (a == '=')
			break;
	}
	

	*/


	return 0;
}




stackli.h

        typedef double ElementType;


        struct Node;
        typedef struct Node *PtrToNode;
        typedef PtrToNode Stack;

        int IsEmpty( Stack S );
        Stack CreateStack( void );
        void DisposeStack( Stack S );
        void MakeEmpty( Stack S );
        void Push( ElementType X, Stack S );
        ElementType Top( Stack S );
        void Pop( Stack S );






stackli.c


        #include "stackli.h"
        #include <stdio.h>
        #include <stdlib.h>

        struct Node
        {
            ElementType Element;
            PtrToNode   Next;
        };

/* START: fig3_40.txt */
        int
        IsEmpty( Stack S )
        {
            return S->Next == NULL;
        }
/* END */

/* START: fig3_41.txt */
        Stack CreateStack()
        {
            Stack S;

            S = malloc( sizeof( struct Node ) );
            if( S == NULL )
                printf( "Out of space!!!" );
            S->Next = NULL;
            MakeEmpty( S );
            return S;
        }

        void
        MakeEmpty( Stack S )
        {
            if( S == NULL )
                printf( "Must use CreateStack first" );
            else
                while( !IsEmpty( S ) )
                    Pop( S );
        }
/* END */

        void
        DisposeStack( Stack S )
        {
            MakeEmpty( S );
            free( S );
        }

/* START: fig3_42.txt */
        void
        Push(ElementType X, Stack S)
        {
            PtrToNode TmpCell;

            TmpCell = malloc( sizeof( struct Node ) );
            if( TmpCell == NULL )
                printf( "Out of space!!!" );
            else
            {
                TmpCell->Element = X;
                TmpCell->Next = S->Next;
                S->Next = TmpCell;
            }
        }
/* END */

/* START: fig3_43.txt */
        ElementType
        Top(Stack S)
        {
            if( !IsEmpty( S ) )
                return S->Next->Element;
            printf( "Empty stack" );
            return 0;  /* Return value used to avoid warning */
        }
/* END */

/* START: fig3_44.txt */
        void
        Pop(Stack S)
        {
            PtrToNode FirstCell;

            if( IsEmpty( S )  )
               printf( "Empty stack" );
            else
            {
                FirstCell = S->Next;
                S->Next = S->Next->Next;
                free( FirstCell );
            }
        }
/* END */

…

```
