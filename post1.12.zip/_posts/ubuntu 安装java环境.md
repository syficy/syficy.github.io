﻿## 先换源
详见我的另外一篇
【https://blog.csdn.net/qq_30600259/article/details/102591569】

## 安装OpenJDK
>sudo apt install default-jre

## 安装Java Development Kit（JDK）

>sudo apt install default-jdk




参考：

https://cloud.tencent.com/developer/article/1162527
