﻿
## 情况
在Ubuntu18.04容器使用  apt install python3-pip  安装pip时报错


 sub-process /usr/bin/dpkg returned an error code (1)


## 解决方案

使用 

curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py &python get-pip.py
