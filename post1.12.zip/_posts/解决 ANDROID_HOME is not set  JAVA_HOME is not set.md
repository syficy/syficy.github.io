﻿解决运行appium-doctor

重启powershell后输入appium-doctor出错
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191022163139571.png)

原因是之前Android配置环境时没配好 ANDRIOD_HOME 

设置环境变量
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191022163433474.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

同理  javahome也是如此
另外 vscode配置完环境之后需要重启

最后

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191022164003844.png)
