﻿# 解决selenium.common.exceptions.InvalidArgumentException: Message: invalid argument: invalid 'expiry'

## 问题描述
最近在使用python爬虫cookie登入时，报错：selenium.common.exceptions.InvalidArgumentException: Message: invalid argument: invalid 'expiry'。

这个‘expiry’是cookie的失效时间，插入的时候出现问题。

## 解决方法

### 1 删除 简单粗暴

既然有错，斩草除根定没错。
直接遍历删掉相应字段
```python
for c in cookie:
    if 'expiry' in c:
        del c['expiry']
    print(c)    
    driver.add_cookie(c)
driver.refresh()
```

### 2 把float改成int

就是如方法一遍历，把‘expiry’对应的数据强制类型转换改成int类型。


