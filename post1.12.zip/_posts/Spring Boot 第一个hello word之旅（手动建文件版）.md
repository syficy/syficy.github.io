﻿# 前言
本人之前未接触过Java，对java仅停留在helloword的水平，本着自顶向下的学习态度，先摸一摸springboot的浑水，于是写下此文，对于同样“吃饱了撑着”的朋友有所借鉴，更重要的在于捋一下浑水摸鱼的思路，日后有所纪念。话不多说，正事开始。



# 环境与编译器选择

>编译器： intellj IDEA 2019.2
>java:     1.8.0
>mvn:   3.6.2

其中mvn从官网上下载
>https://www-us.apache.org/dist/maven/maven-3/3.6.2/

在windows下运行的所以是 
**apache-maven-3.6.2-bin.zip**
文件
下载安装并且配置环境变量,注意JAVA_HOME的配置

最终mvn版本为：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191102210429271.png)

# 项目配置
## 项目创建
intellj->new project -> maven 选择1.8.0的sdk包然后next
输入GroupId 和 AerfactId 我分别命名为com.syfcy 和 spring-boot-helloword。 然后next 下去，进入项目。

## 配置pom.xml

在pom.xml中加入以下代码
先导入父项目为spring-boot-starter-parent，这是真正管理应用的所有依赖版本，是springboot应用的所有依赖版本，也是默认版本。


然后导入**spring-boot-starter**-web依赖
spring-boot-starter： 场景启动器，声明一些依赖导入，帮助导入web相关的依赖，版本由父项目决定。spring将功能场景抽取出来，做出一个个启动器。

更多可在官网看
https://spring.io/projects/spring-boot#learn


```java
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>1.5.9.RELEASE</version>
    </parent>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
    </dependencies>
```
## controller文件创建
右击java新建类为“com.syfcy.HelloController，IDEA会在java下创建com.syfcy文件，并在其中建立HelloController.java文件，加入以下
(在IDEA中@之后右击可直接导入）

```java
package com.syfcy.contorller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {
    @ResponseBody
    @RequestMapping("/hello")
    public String hello(){
        return "hello word";
    }
}

```

## HelloWorldMainApplication.java文件

在com.syfcy中的HelloWorldMainApplication.java文件中加入以下代码


```java
package com.syfcy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorldMainApplication {
    public static void main(String[] args) {
        SpringApplication.run(HelloWorldMainApplication.class,args);
    }
}

```

这是主程序主入口类
这个springbootapplication类ctrl打开可以看到
这里的概念太复杂了，就不写了先，有空补上

```java
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@SpringBootConfiguration //配置
@EnableAutoConfiguration //开启自动配置
@ComponentScan(
    excludeFilters = {@Filter(
    type = FilterType.CUSTOM,
    classes = {TypeExcludeFilter.class}
), @Filter(
    type = FilterType.CUSTOM,
    classes = {AutoConfigurationExcludeFilter.class}
)}
)
public @interface SpringBootApplication {

```


# 运行
点击运行，springboot会自动启动tomcat，访问本地localhost:8080，即可看到
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191102212625833.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

主页报错可以忽略
在url后面加入/hello
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191102212702767.png)
代表成功（world打错了，读者请忽略）

# 打包为jar
在pom.xml中插入
```java
    <!--这个插件可以将应用打包为可执行jar包 -->
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
```
然后再idea的右边点击maven，点击package，就在项目目录下生存了.jar文件
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191102212909313.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

复制文件运行：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191102212932619.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

成功运行（自带tomcat，可在服务器上运行）
使用压缩软件打开jar包可看到自带lib库
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191102213119999.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)
