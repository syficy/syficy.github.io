﻿
## Shell 简介

早期计算机没有图形界面，用户是通过命令行（比如windows的cmd，linux下的shell）操作计算机的，而真正实际操作计算的是kernel（操作系统内核），图形界面亦或命令行都是间接操作内核以控制系统的。

在linux下，Shell就是这个命令行程序。
因此,shell 是一个程序，是一个建立在内核基础上的程序，而不是内核的一部分，在linux中用户通过Shell来使用linux，不启动shell则无法使用。

在shell中输入东西的时候，Shell会调用内核的接口函数，内核一顿操作后再返回给Shell，Shell除了可以使用自带的内置命令，也可以使用外置命令。

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191030144028460.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMwNjAwMjU5,size_16,color_FFFFFF,t_70)

## Shell编程
编程语言可以分为：

 1.  编译型语言： C/C++ Pacal Go 汇编等等，运行前都需要先编译成二进制可执行文件，依靠编译器。
 2. 解释型语言（脚本语言） ： Shell Javascript Python Php等，即时翻译，边执行边翻译，依靠解释器。

注： 这种分类方法并不严谨，比如java语言是属于编译型还是解释型一直有争论，因为java先要编译为字节码，再再jvm上解释执行，我认为纠结于这种争论没有意义，一般认为java是一种编译型语言。

Shell是一种脚本语言，可以执行源码。

## 不同的Shell
常见的Shell 有 sh，bah，csh等等
其中bash shell是Linux默认的shell程序。
程序一般在/bin 或 /usr/bin目录下，可用的shell记录在/etc/shells中

## DOS简介
dos，是磁盘操作系统（Disk Operating System）的缩写，是一类操作系统，早期dos分为多种，以微软旗下MS_DOS使用人数最多，而后微软放弃该系统，转而开发windows，1998后windos彻底脱离dos，但是留下了命令行的批处理程序。

## cmd与dos
一般认为cmd属于windows的一部分，只是保留了一部分dos中的命令。

## cmd与bash
>cmd是Command shell的简写，微软的定义是：The command shell is a separate software program that provides direct communication between the user and the operating system. The non-graphical command shell user interface provides the environment in which you run character-based applications and utilities. The command shell executes programs and displays their output on the screen by using individual characters similar to the MS-DOS command interpreter Command.com.（CommandShell是一个独立的应用程序，它为用户提供对操作系统直接通信的功能，它为基于字符的应用程序和工具提供了非图形界面的运行环境，它执行命令并在屏幕上回显MS-DOS风格的字符。）所以，可以近似地认为linux shell=bash而windows=cmd，都是命令行解释器，都是用户与操作系统的交互接口。但是bash要比cmd强大很多，windows也有强大的shell叫windows power shell。

链接：https://blog.csdn.net/qq_34719188/article/details/84073200#linux_shellbashwindows_cmd_29

## 批处理
批量处理即为批处理，是一种简化的脚本语言，应用于windows系统中，类似于shell脚本，批处理文件是由类dos命令组成的文本文件，可在windows系统中运行，一般以.bat为后缀

教程链接：https://www.w3cschool.cn/dosmlxxsc1/wvqyr9.html
