﻿## 保存cookie
可以使用自动化填入账号密码登入，但我倾向去用input暂停然后手动登入，再获取cookie保存到文件中


```python
from selenium import webdriver
import time,json


url = 'xxxx'
driver = webdriver.Chrome()
driver.get(url)
input("dengru")
cookies = driver.get_cookies()
print(cookies)
f1 = open('cookie.txt','w')
f1.write(json.dumps(cookies))
f1.close()

```

## 读取cookie

```python
driver.delete_all_cookies()
f1 = open('cookie.txt')
cookie = json.loads(f1.read()) //有人说最好用load读文件 我也不知道为啥
f1.close()


for c in cookie:
    driver.add_cookie(c)
driver.refresh()


```
这样可能会报错invalid argument: invalid ‘expiry’

参考我的另外一篇文章
https://blog.csdn.net/qq_30600259/article/details/102673452
把for循环以下改成下面的就行了



```python
for c in cookie:
    if 'expiry' in c:
        del c['expiry']
    print(c)    
    driver.add_cookie(c)
driver.refresh()
```
