﻿# 题目
(1)	Task description: 
There is a kind of balanced binary search tree named red-black tree in the data structure. It has the following 5 properties:
(1) Every node is either red or black.
(2) The root is black.
(3) Every leaf (NULL) is black.
(4) If a node is red, then both its children are black.
(5) For each node, all simple paths from the node to descendant leaves contain the same number of black nodes.
For each given binary search tree, you are supposed to tell if it is a legal red-black tree.


 (2) Methods: 
1. Using insert function to build the red-black tree, judging the absolute value of the number and the element of the node.
2. The rule 1 and 3 are must true, so we just need to judge the rule 2,4,5.
3. Rule 2 is easy.
4. Rule 4, I use a recursive function to judge. When the node is null, the function will end. If a red node has a red children node, the function will return false. 
5. Rule 5, I first calculate the number of black nodes in the leftmost subtree path, than use the recursive function to calculate the number of black nodes of every paths of the tree, if not equal, return false.



# 代码实现
```c
# include<stdio.h>

typedef struct TreeNode* Tree;

//值的大小来表示红黑树，负数为红，正数为黑

struct TreeNode {
	int Element;
	Tree  Left;
	Tree  Right;
};
int baseBlack = 0; //定义最左边子树路径的黑色节点数


//通过插入函数，把前序转化为二叉树
void insert(Tree T,int number)
{
	if (abs(number) <= abs(T->Element))
	{
		if (T->Left == NULL)
		{
			T->Left = malloc(sizeof(struct TreeNode));
			T->Left->Element = number;
			T->Left->Left = NULL;
			T->Left->Right = NULL;
			return;
		}
		else
			insert(T->Left, number);
	}
	else
	{
		if (T->Right == NULL)
		{
			T->Right = malloc(sizeof(struct TreeNode));
			T->Right->Element = number;
			T->Right->Left = NULL;
			T->Right->Right = NULL;
			return;
		}
		else
			insert(T->Right, number);
	}
}
//第一条和第三条一定是满足的  需要判断的是规则2，4，5

// judge (2) The root is black.
// 判断第二条规则 根是否为黑色
int judgeRull2(Tree rbtree)
{
	if (rbtree->Element < 0) return 0;
}


// judge (4) If a node is red, then both its children are black.
// 通过递归，判断第四个规则是否成立
int judgeRull4(Tree rbtree)
{
	if (rbtree == NULL) return 1;
	if (rbtree->Element < 0)
	{
		if (!rbtree->Left) return 1; //如果为空 返回1
		if (rbtree->Left->Element < 0) //非空 看看值
		{
			return 0;
		}
		if (!rbtree->Right) return 1;
		if (rbtree->Right->Element < 0)
		{
			return 0;
		}
	}
	return judgeRull4(rbtree->Left) && judgeRull4(rbtree->Right);
}


//获得最左边路径子树的黑色节点个数，作为比较的基准，后面的所有路径的黑色节点个数应该等于这个
void blackOfLeft(Tree rbtree)
{
	while (rbtree != NULL)
	{
		if (rbtree->Element > 0)
			baseBlack++;
		rbtree = rbtree->Left;
	}
}



//judge (5) For each node, all simple paths from the node to descendant leaves contain the same number of black nodes.
// 通过递归比较每个路径的黑色节点个数是否等于最左边的路径的黑色节点个数
int judgeRull5(Tree rbtree,int count)
{
	if (rbtree == NULL) return 1;
	if (rbtree->Element > 0) count++;
	if (rbtree->Right == NULL && rbtree->Left == NULL)
	{
		if (count != baseBlack) return 0;
	}
	return judgeRull5(rbtree->Left, count) && judgeRull5(rbtree->Right, count);
}


int main()
{
	Tree rbtree = malloc(sizeof(struct TreeNode));
	


	int N;
	printf("Please input the number of nodes first,and then input the preorder traversal sequence of the tree\n");
	scanf("%d", &N);
	int tempElement;

	//先输入根节点，并初始化，再顺序输入
	scanf("%d", &tempElement);
	rbtree->Element = tempElement;
	rbtree->Left = NULL;
	rbtree->Right = NULL;


	
	for (int i = 1; i < N; i++)
	{
		scanf("%d", &tempElement);
		insert(rbtree, tempElement);
	}

	blackOfLeft(rbtree);
	if (judgeRull2 && judgeRull4 && judgeRull5) printf("Yes");
	else printf("No");

	return 0;
}
```

# 实现

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191108165922778.png)
